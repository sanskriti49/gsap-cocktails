Terms Of Use
By downloading or using our font, you are read and accept to the Our Term and Use Agreement :

This font is copyrighted and protected by the law. Usage of this font on any work without proper license is deemed as illegal. 

You might get fined for at least USD 3000 for this act. Please do understand that we have our own system for tracking the usage of our works on internet.

- Our free demo is ONLY for NON COMMERCIAL USE or PERSONAL USE ONLY

- Click this link to purchase in our website :
sohelstudio05.gumroad.com/l/ModernNegra

-You may not Capture screen shots, record video, record audio and copy text from products to use as press material, without permission from our company.

- For Corporate or Commercial use you have to purchase Corporate and commercial license, please contact us at :
Rifaiozil05@gmail.com

- Any donation are acceptable and very appreciated. Here is Our Paypal account for donation :
Rifaiozil05@gmail.com

If you purchase a commercial use license, you will receive a package that includes:

